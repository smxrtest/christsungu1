import { HeroSection } from "@/components/hero-section"
import { AboutSection } from "@/components/about-section"
import { AcademicsSection } from "@/components/academics-section"
import { SportsSection } from "@/components/sports-section"
import { HighlightsSection } from "@/components/highlights-section"
import { SocialSection } from "@/components/social-section"
import { Navigation } from "@/components/navigation"

export default function Home() {
  return (
    <main className="min-h-screen bg-background">
      <Navigation />
      <HeroSection />
      <AboutSection />
      <AcademicsSection />
      <SportsSection />
      <HighlightsSection />
      <SocialSection />
    </main>
  )
}
