import { Card, CardContent } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Instagram, Youtube, Mail, Phone, MapPin } from "lucide-react"

export function SocialSection() {
  const socialLinks = [
    {
      icon: Instagram,
      label: "Instagram",
      href: "https://instagram.com/ch.ris_tsu",
      color: "hover:text-pink-500",
    },
    {
      icon: () => (
        <svg viewBox="0 0 24 24" width="24" height="24" fill="currentColor">
          <path d="M19.59 6.69a4.83 4.83 0 0 1-3.77-4.25V2h-2.08v5.73a3.87 3.87 0 0 1-3.87 3.87 3.87 3.87 0 0 1-3.87-3.87 3.87 3.87 0 0 1 3.87-3.87c.21 0 .42.01.62.05V1.83c-.2-.02-.4-.03-.62-.03A5.94 5.94 0 0 0 3.93 7.74a5.94 5.94 0 0 0 5.94 5.94 5.94 5.94 0 0 0 5.94-5.94V9.69a6.86 6.86 0 0 0 3.77 1.06V8.84a4.83 4.83 0 0 1-3.77-2.15z" />
        </svg>
      ),
      label: "TikTok",
      href: "https://tiktok.com/@chris28376",
      color: "hover:text-black",
    },
    {
      icon: Youtube,
      label: "YouTube",
      href: "#",
      color: "hover:text-red-500",
    },
    {
      icon: Mail,
      label: "Email",
      href: "mailto:cctsungu@gmail.com",
      color: "hover:text-green-500",
    },
  ]

  const contactInfo = [
    {
      icon: Phone,
      label: "Phone",
      value: "07858927169",
    },
    {
      icon: MapPin,
      label: "Location",
      value: "Witham, Essex",
    },
  ]

  return (
    <section id="contact" className="py-20 px-4 sm:px-6 lg:px-8">
      <div className="max-w-4xl mx-auto">
        <div className="text-center mb-16">
          <h2 className="text-4xl sm:text-5xl font-bold mb-6 text-balance">Let's Connect</h2>
          <p className="text-xl text-muted-foreground text-balance max-w-3xl mx-auto">
            Follow my journey and get in touch for opportunities, collaborations, or just to say hello
          </p>
        </div>

        <div className="grid md:grid-cols-2 gap-8 mb-12">
          {/* Social Links */}
          <Card className="bg-card/80 backdrop-blur-sm">
            <CardContent className="p-8">
              <h3 className="text-2xl font-semibold mb-6 text-center">Follow My Journey</h3>
              <div className="grid grid-cols-2 gap-4">
                {socialLinks.map((social) => (
                  <Button
                    key={social.label}
                    variant="outline"
                    size="lg"
                    className={`h-16 flex-col gap-2 border-border/50 hover:border-secondary/50 ${social.color} transition-all duration-300`}
                    asChild
                  >
                    <a href={social.href} target="_blank" rel="noopener noreferrer">
                      <social.icon size={24} />
                      <span className="text-sm">{social.label}</span>
                    </a>
                  </Button>
                ))}
              </div>
            </CardContent>
          </Card>

          {/* Contact Info */}
          <Card className="bg-card/80 backdrop-blur-sm">
            <CardContent className="p-8">
              <h3 className="text-2xl font-semibold mb-6 text-center">Get In Touch</h3>
              <div className="space-y-6">
                {contactInfo.map((info) => (
                  <div key={info.label} className="flex items-center gap-4">
                    <div className="p-2 rounded-lg bg-secondary/10 text-secondary">
                      <info.icon size={20} />
                    </div>
                    <div>
                      <div className="font-medium">{info.label}</div>
                      <div className="text-muted-foreground text-sm">{info.value}</div>
                    </div>
                  </div>
                ))}
              </div>

              <div className="mt-8 p-4 bg-muted/50 rounded-lg">
                <p className="text-sm text-muted-foreground text-center">
                  Open to opportunities in football, technology, and academic collaborations. Let's build something
                  amazing together!
                </p>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Footer */}
        <div className="text-center py-8 border-t border-border/50">
          <p className="text-muted-foreground">© 2025 Chris Tsungu. Built with passion and dedication.</p>
        </div>
      </div>
    </section>
  )
}
