import { Card, CardContent } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"

export function AboutSection() {
  const traits = ["Ambitious", "Risk-Taking", "Time Management", "Computer Enthusiast", "Team Player", "Dedicated"]

  return (
    <section id="about" className="py-20 px-4 sm:px-6 lg:px-8">
      <div className="max-w-4xl mx-auto">
        <div className="text-center mb-16">
          <h2 className="text-4xl sm:text-5xl font-bold mb-6 text-balance">About Me</h2>
          <p className="text-xl text-muted-foreground text-balance max-w-3xl mx-auto">
            A passionate young athlete and technology enthusiast who believes in taking calculated risks and making
            every moment count.
          </p>
        </div>

        <div className="grid md:grid-cols-2 gap-8 items-center">
          <div>
            <Card className="p-8 bg-card/50 backdrop-blur-sm border-border/50">
              <CardContent className="p-0">
                <h3 className="text-2xl font-semibold mb-4">My Story</h3>
                <p className="text-muted-foreground mb-6 leading-relaxed">
                  At 15, I'm already making my mark both on the football pitch and in the digital world from my home in
                  Colchester, Essex. Playing for FITC Academy Witham Town EJA U15, I bring the same dedication and
                  strategic thinking to my academic pursuits at Stanway School.
                </p>
                <p className="text-muted-foreground leading-relaxed">
                  My passion for technology led me to choose Computer Science and Media Studies for my GCSEs. I'm not
                  afraid to take chances and believe that smart risks lead to extraordinary outcomes.
                </p>
              </CardContent>
            </Card>
          </div>

          <div className="space-y-6">
            <div>
              <h3 className="text-xl font-semibold mb-4">Key Traits</h3>
              <div className="flex flex-wrap gap-2">
                {traits.map((trait) => (
                  <Badge
                    key={trait}
                    variant="secondary"
                    className="px-3 py-1 text-sm bg-secondary/10 text-secondary border-secondary/20"
                  >
                    {trait}
                  </Badge>
                ))}
              </div>
            </div>

            <div className="grid grid-cols-2 gap-4">
              <Card className="p-4 text-center bg-muted/30">
                <CardContent className="p-0">
                  <div className="text-2xl font-bold text-secondary">5'11"</div>
                  <div className="text-sm text-muted-foreground">Height</div>
                </CardContent>
              </Card>
              <Card className="p-4 text-center bg-muted/30">
                <CardContent className="p-0">
                  <div className="text-2xl font-bold text-secondary">70kg</div>
                  <div className="text-sm text-muted-foreground">Weight</div>
                </CardContent>
              </Card>
            </div>
          </div>
        </div>
      </div>
    </section>
  )
}
