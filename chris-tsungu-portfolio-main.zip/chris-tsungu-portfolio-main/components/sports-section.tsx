import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Trophy, Target, Users, Zap } from "lucide-react"

export function SportsSection() {
  const achievements = [
    {
      icon: Trophy,
      title: "Multi-Sport Champion",
      description: "District champion in 200m sprint and long jump, showcasing exceptional speed and athleticism",
      highlight: "Track & Field",
    },
    {
      icon: Target,
      title: "FITC Academy Player",
      description: "Training and developing skills with FITC Academy's elite youth development program",
      highlight: "Development",
    },
    {
      icon: Users,
      title: "Witham Town FC",
      description: "Competing at club level, representing Witham Town FC in competitive matches",
      highlight: "Club Football",
    },
    {
      icon: Zap,
      title: "Athletic Performance",
      description: "Combining elite speed, agility, and technical skills at 5'11\" and 70kg",
      highlight: "Physical Stats",
    },
  ]

  const stats = [
    { label: "Height", value: "5'11\"" },
    { label: "Weight", value: "70kg" },
    { label: "Position", value: "LW/RW/CAM/ST" },
    { label: "Speciality", value: "Speed & Agility" },
  ]

  return (
    <section id="sports" className="py-20 px-4 sm:px-6 lg:px-8">
      <div className="max-w-6xl mx-auto">
        <div className="text-center mb-16">
          <h2 className="text-4xl sm:text-5xl font-bold mb-6 text-balance">Athletic Journey</h2>
          <p className="text-xl text-muted-foreground text-balance max-w-3xl mx-auto">
            Multi-sport athlete excelling in football and track & field with district championship titles
          </p>
        </div>

        {/* Stats Grid */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-12">
          {stats.map((stat) => (
            <Card key={stat.label} className="text-center bg-secondary/5 border-secondary/20">
              <CardContent className="p-6">
                <div className="text-2xl font-bold text-secondary mb-1">{stat.value}</div>
                <div className="text-sm text-muted-foreground">{stat.label}</div>
              </CardContent>
            </Card>
          ))}
        </div>

        {/* Achievements Grid */}
        <div className="grid md:grid-cols-2 gap-6">
          {achievements.map((achievement) => (
            <Card
              key={achievement.title}
              className="group hover:shadow-lg transition-all duration-300 bg-card/80 backdrop-blur-sm"
            >
              <CardHeader className="pb-4">
                <div className="flex items-start justify-between">
                  <div className="flex items-center gap-3">
                    <div className="p-2 rounded-lg bg-secondary/10 text-secondary group-hover:bg-secondary group-hover:text-secondary-foreground transition-colors duration-300">
                      <achievement.icon size={24} />
                    </div>
                    <div>
                      <CardTitle className="text-lg">{achievement.title}</CardTitle>
                      <Badge variant="secondary" className="mt-1 text-xs">
                        {achievement.highlight}
                      </Badge>
                    </div>
                  </div>
                </div>
              </CardHeader>
              <CardContent>
                <p className="text-muted-foreground leading-relaxed">{achievement.description}</p>
              </CardContent>
            </Card>
          ))}
        </div>

        {/* Team Info */}
        <Card className="mt-12 bg-gradient-to-r from-secondary/10 to-accent/10 border-secondary/20">
          <CardContent className="p-8 text-center">
            <h3 className="text-2xl font-semibold mb-4">Football & Athletics</h3>
            <div className="grid md:grid-cols-2 gap-6 text-left">
              <div>
                <h4 className="font-semibold text-lg mb-2">FITC Academy</h4>
                <p className="text-muted-foreground leading-relaxed">
                  Elite youth development program focusing on technical skills, tactical awareness, and professional
                  preparation.
                </p>
              </div>
              <div>
                <h4 className="font-semibold text-lg mb-2">Witham Town FC</h4>
                <p className="text-muted-foreground leading-relaxed">
                  Competitive club football representing Witham Town FC in league matches and tournaments.
                </p>
              </div>
            </div>
            <div className="mt-6 pt-6 border-t border-secondary/20">
              <h4 className="font-semibold text-lg mb-2">Track & Field Achievements</h4>
              <p className="text-muted-foreground leading-relaxed">
                District champion in 200m sprint and long jump, demonstrating exceptional speed and athletic versatility
                that translates directly to football performance.
              </p>
            </div>
          </CardContent>
        </Card>
      </div>
    </section>
  )
}
