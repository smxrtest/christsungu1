import { Button } from "@/components/ui/button"
import { ArrowDown } from "lucide-react"

export function HeroSection() {
  return (
    <section className="relative min-h-screen flex items-center justify-center overflow-hidden">
      {/* Background Image */}
      <div className="absolute inset-0 z-0">
        <img src="/picofme2.jpg" alt="Chris Tsungu playing football" className="w-full h-full object-cover" />
        <div className="absolute inset-0 bg-black/40" />
      </div>

      {/* Content */}
      <div className="relative z-10 text-center text-white px-4 sm:px-6 lg:px-8">
        <h1 className="text-5xl sm:text-6xl lg:text-7xl font-bold mb-6 text-balance">Chris Tsungu</h1>
        <p className="text-xl sm:text-2xl lg:text-3xl mb-8 text-balance opacity-90">
          Young Athlete & Aspiring Developer
        </p>
        <div className="flex flex-col sm:flex-row gap-4 justify-center items-center mb-12">
          <div className="text-lg">
            <span className="font-semibold">5'11"</span> • <span className="font-semibold">70kg</span>
          </div>
          <div className="hidden sm:block w-px h-6 bg-white/50" />
          <div className="text-lg">FITC Academy Witham Town EJA U15</div>
        </div>

        <Button size="lg" className="bg-secondary hover:bg-secondary/90 text-secondary-foreground" asChild>
          <a href="#about">Discover My Journey</a>
        </Button>
      </div>

      {/* Scroll Indicator */}
      <div className="absolute bottom-8 left-1/2 transform -translate-x-1/2 text-white animate-bounce">
        <ArrowDown size={24} />
      </div>
    </section>
  )
}
