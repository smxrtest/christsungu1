"use client"

import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Play, Upload, Video, ExternalLink } from "lucide-react"
import { useState } from "react"

export function HighlightsSection() {
  const [playingVideo, setPlayingVideo] = useState<number | null>(null)

  const videoHighlights = [
    {
      title: "Match Performance #1",
      description: "Showcasing technical skills and game awareness in competitive action",
      duration: "Live",
      url: "https://youtu.be/LAnpaF7930M",
      embedUrl: "https://www.youtube.com/embed/LAnpaF7930M",
      thumbnail: "/chris-highlight-1.jpg",
    },
    {
      title: "Match Performance #2",
      description: "Demonstrating versatility and tactical understanding on the pitch",
      duration: "Live",
      url: "https://youtu.be/jwxbWTalZwc",
      embedUrl: "https://www.youtube.com/embed/jwxbWTalZwc",
      thumbnail: "/chris-highlight-2.jpg",
    },
    {
      title: "Match Performance #3",
      description: "Quick skills showcase highlighting pace and ball control",
      duration: "Short",
      url: "https://youtube.com/shorts/98kO0aQ2guQ?feature=share",
      embedUrl: "https://www.youtube.com/embed/98kO0aQ2guQ",
      thumbnail: "/chris-highlight-3.jpg",
    },
  ]

  return (
    <section id="highlights" className="py-20 px-4 sm:px-6 lg:px-8 bg-muted/30">
      <div className="max-w-6xl mx-auto">
        <div className="text-center mb-16">
          <h2 className="text-4xl sm:text-5xl font-bold mb-6 text-balance">Game Highlights</h2>
          <p className="text-xl text-muted-foreground text-balance max-w-3xl mx-auto">
            Watch me in action - showcasing skills, teamwork, and dedication on the pitch
          </p>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6 mb-12">
          {videoHighlights.map((video, index) => (
            <Card key={index} className="group hover:shadow-lg transition-all duration-300 overflow-hidden">
              <div className="relative aspect-video bg-muted/50">
                {playingVideo === index ? (
                  <iframe
                    src={video.embedUrl}
                    title={video.title}
                    className="w-full h-full"
                    frameBorder="0"
                    allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
                    allowFullScreen
                  />
                ) : (
                  <>
                    <img
                      src={video.thumbnail || "/placeholder.svg"}
                      alt={video.title}
                      className="w-full h-full object-cover"
                    />
                    <div className="absolute inset-0 bg-black/40 group-hover:bg-black/30 transition-colors duration-300" />
                    <div className="absolute inset-0 flex items-center justify-center">
                      <Button
                        size="lg"
                        className="bg-white/20 hover:bg-white/30 text-white border-white/30 backdrop-blur-sm"
                        variant="outline"
                        onClick={() => setPlayingVideo(index)}
                      >
                        <Play size={20} className="mr-2" />
                        Play
                      </Button>
                    </div>
                    <div className="absolute bottom-2 right-2 bg-black/60 text-white text-xs px-2 py-1 rounded">
                      {video.duration}
                    </div>
                    <div className="absolute top-2 right-2">
                      <Button
                        size="sm"
                        variant="ghost"
                        className="h-8 w-8 p-0 bg-black/20 hover:bg-black/40 text-white"
                        onClick={() => window.open(video.url, "_blank")}
                      >
                        <ExternalLink size={14} />
                      </Button>
                    </div>
                  </>
                )}
              </div>
              <CardHeader className="pb-2">
                <CardTitle className="text-lg">{video.title}</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-muted-foreground text-sm">{video.description}</p>
              </CardContent>
            </Card>
          ))}
        </div>

        <Card className="bg-gradient-to-r from-secondary/5 to-accent/5 border-secondary/20">
          <CardContent className="p-8 text-center">
            <Video className="mx-auto mb-4 text-secondary" size={48} />
            <h3 className="text-2xl font-semibold mb-4">More Highlights Coming Soon</h3>
            <p className="text-muted-foreground mb-6 text-balance max-w-2xl mx-auto">
              I'm constantly working on improving my game and capturing new highlights. Check back regularly for the
              latest footage of my development as a player.
            </p>
            <Button
              variant="outline"
              className="border-secondary/30 text-secondary hover:bg-secondary hover:text-secondary-foreground bg-transparent"
            >
              <Upload size={16} className="mr-2" />
              Request Highlights
            </Button>
          </CardContent>
        </Card>
      </div>
    </section>
  )
}
