import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { GraduationCap, Monitor, Camera, BookOpen, Globe } from "lucide-react"

export function AcademicsSection() {
  const subjects = [
    {
      icon: Monitor,
      title: "Computer Science GCSE",
      description: "Developing programming skills and understanding computational thinking",
      skills: ["Programming", "Algorithms", "Data Structures", "Problem Solving"],
    },
    {
      icon: Camera,
      title: "Media Studies GCSE",
      description: "Exploring digital media creation and understanding modern communication",
      skills: ["Digital Design", "Video Production", "Media Analysis", "Creative Thinking"],
    },
    {
      icon: BookOpen,
      title: "History (High Level)",
      description: "Analyzing historical events and developing critical thinking skills",
      skills: ["Critical Analysis", "Research", "Essay Writing", "Historical Context"],
    },
    {
      icon: Globe,
      title: "Spanish (High Level)",
      description: "Mastering language skills and exploring Hispanic culture",
      skills: ["Fluency", "Grammar", "Cultural Understanding", "Communication"],
    },
  ]

  return (
    <section id="academics" className="py-20 px-4 sm:px-6 lg:px-8 bg-muted/30">
      <div className="max-w-6xl mx-auto">
        <div className="text-center mb-16">
          <h2 className="text-4xl sm:text-5xl font-bold mb-6 text-balance">Academic Excellence</h2>
          <p className="text-xl text-muted-foreground text-balance max-w-3xl mx-auto">
            Pursuing knowledge with the same intensity I bring to the football field
          </p>
        </div>

        <div className="grid md:grid-cols-2 gap-8 mb-12">
          {subjects.map((subject) => (
            <Card
              key={subject.title}
              className="group hover:shadow-lg transition-all duration-300 bg-card/80 backdrop-blur-sm"
            >
              <CardHeader className="pb-4">
                <div className="flex items-center gap-3 mb-2">
                  <div className="p-2 rounded-lg bg-secondary/10 text-secondary group-hover:bg-secondary group-hover:text-secondary-foreground transition-colors duration-300">
                    <subject.icon size={24} />
                  </div>
                  <CardTitle className="text-xl">{subject.title}</CardTitle>
                </div>
                <p className="text-muted-foreground leading-relaxed">{subject.description}</p>
              </CardHeader>
              <CardContent>
                <div className="flex flex-wrap gap-2">
                  {subject.skills.map((skill) => (
                    <Badge key={skill} variant="outline" className="text-xs border-secondary/30 text-secondary">
                      {skill}
                    </Badge>
                  ))}
                </div>
              </CardContent>
            </Card>
          ))}
        </div>

        <Card className="bg-gradient-to-r from-secondary/5 to-accent/5 border-secondary/20">
          <CardContent className="p-8 text-center">
            <GraduationCap className="mx-auto mb-4 text-secondary" size={48} />
            <h3 className="text-2xl font-semibold mb-2">Stanway School</h3>
            <p className="text-muted-foreground text-balance">
              Committed to academic excellence while balancing my passion for football and technology. I believe in
              using my time wisely to excel in every area of my life.
            </p>
          </CardContent>
        </Card>
      </div>
    </section>
  )
}
